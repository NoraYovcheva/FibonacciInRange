using System.Linq;
using NUnit.Framework;
using System.Collections.Generic;

namespace TestApp.Tests;

public class LongestStringFinderTests
{

    [Test]
    public void Test_GetLongestString_EmptyList_ReturnsEmptyString()
    {
        
    }

    [Test]
    public void Test_GetLongestString_NullList_ReturnsEmptyString()
    {

    }

    [Test]
    public void Test_GetLongestString_OneElementInList_ReturnsThisWordAsString()
    {

    }

    [Test]
    public void Test_GetLongestString_ManyWordWithDiffrentLength_ReturnsLongestWord()
    {

    }

    [Test]
    public void Test_GetLongestString_ManyWordWithSameLength_ReturnsFirstWordOfThem()
    {

    }
}
