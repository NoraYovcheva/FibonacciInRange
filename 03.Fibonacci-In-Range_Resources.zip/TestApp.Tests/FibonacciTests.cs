using System.Linq;
using NUnit.Framework;
using System.Collections.Generic;

namespace TestApp.Tests;

public class FibonacciTests
{

    [Test]
    public void Test_FibonacciInRange_StartNumberGreaterThanEndNumber_ReturnsErrorMessage()
    {
        
    }

    [Test]
    public void Test_FibonacciInRange_StartAndEndNumberEqualToZero_ReturnsZero()
    {

    }

    [Test]
    public void Test_FibonacciInRange_StartAndEndNumberEqualToOne_ReturnsTwoTimesOne()
    {

    }

    [Test]
    public void Test_FibonacciInRange_NoFibonacciNumberBetweenStartAndEndNumbers_ReturnsEmptyString()
    {

    }

    [Test]
    public void Test_FibonacciInRange_ValidRange_ReturnsFibonacciSequence()
    {

    }
}

